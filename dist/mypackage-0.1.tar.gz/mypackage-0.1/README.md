#mypackage
this libary was created as an example to publish your own Python package

#How to instal
....